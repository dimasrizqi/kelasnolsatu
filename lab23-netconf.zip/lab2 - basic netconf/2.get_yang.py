from ncclient import manager
import xml.etree.ElementTree as ET
import sys

host = str(sys.argv[1])
port = str(sys.argv[2])
username = str(sys.argv[3])
password = str(sys.argv[4])
model = str(sys.argv[5])

m = manager.connect(host=host, port=port, username=username,
                    password=password, device_params={'name': 'csr'})


schema = m.get_schema(model)
xml_et = ET.fromstring(schema.xml)
yang = list(xml_et)[0].text

with open(model+'.yang', 'w') as f:
     f.write(yang)


## Using this Files
## ptyhon 2.get_yang.py {ip-address} {netconf-port} {username} {password} {yang-model}
