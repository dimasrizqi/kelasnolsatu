from ietf_ip_binding import ietf_interfaces
model = ietf_interfaces()

m = model.get()
print (m)