from ietf_ip_binding import ietf_interfaces
import pyangbind.lib.pybindJSON as pybindJSON
import json

model = ietf_interfaces()
new_interface = model.interfaces.interface.add('GigabitEthernet2')
# print new_interface.get()

## setting new interfaces description
new_interface.description = 'NETCONF-CONFIGURED PORT'
new_interface.enabled = "True"
# print new_interface.get()['description']

ipv4 = new_interface.ipv4.address.add('1.1.1.1')
ipv4.netmask = '255.255.255.0'
# print ipv4.get()

json_data = pybindJSON.dumps(model, mode='ietf')

with open('new_interface.json', 'w') as f:
     f.write(json_data)
