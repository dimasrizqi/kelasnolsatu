
#importing the modules
import os
import json
import pexpect

#fungtion to write some device information (ipaddr,etc) into database_local and export to the json.
def writedev():

    if os.path.exists('database.json') == False:
        database_local={"ipaddr":[],"username":[],"password":[],"enapass":[]}
    else:
        database_local= json.load(open("database.json"))
    
    x=int(input(" Masukan jumlah device yang akan diinput : "))
    
    a=len(database_local['ipaddr'])
    y=x+a
    while a<y:
        print ("\n Database Perangkat ke-",a+1)
        database_local['ipaddr'].append(str(input(" IP Address : ")))
        database_local['username'].append(str(input(" Username : ")))
        database_local['password'].append(str(input(" Password : ")))
        database_local['enapass'].append(str(input(" Enable Password : ")))
        print ("\n")
        a+=1

    json.dump(database_local, open("database.json",'w'))

#fungtion to view the device information, inport json file into database_local, and read from database_local.
def viewdev():
    if os.path.exists('database.json') == True:
        database_local = json.load(open("database.json","r"))
        x=len(database_local['ipaddr'])
        a=0
        while a<x:
            print ("\n Database Perangkat ke-",a+1)
            print (" IP Address         : ",database_local['ipaddr'][a])
            print (" Username           : ",database_local['username'][a])
            print (" Password           : ",database_local['password'][a])
            print (" Enable Password    : ",database_local['enapass'][a])
            print ("\n")
            a+=1
    else:
        print (" Belum ada data!")

def menu():
    while True:
        os.system('clear')
        print(" Konfigurasi Perangkat")
        x=int(input(" 1. Check Tabel Routing\n 2. Check Interfaces UP\n 3. Check Uptime\n 4. Exit (1/2/3/4) : "))
        if x==1:
            os.system('clear')
            connect('routecheck')
            input('\n Tekan sembarang untuk kembali ke menu')
        elif x==2:
            os.system('clear')
            connect('checkinterfaces')
            input('\n Tekan sembarang untuk kembali ke menu')
        elif x==3:
            os.system('clear')
            connect('checkuptime')
            input('\n Tekan sembarang untuk kembali ke menu')
        elif x==4:
            break
        else:
            continue

'''
fungtion connect : to connect to the device with loops
import database.json into database_local
looping with database_local
    connecting to the device with loops
'''
def connect(command):
    if os.path.exists('database.json') == True:
        database_local = json.load(open("database.json"))

        #total ip address in the database local and looping with that variable.
        x=len(database_local['ipaddr'])
        a=0

        #looping contition
        while a<x:
            print("------------------------------------------")
            print(">  Trying to connect to ",database_local['ipaddr'][a])
            print("------------------------------------------")

            #begin the session.
            session=pexpect.spawn("telnet "+database_local['ipaddr'][a],timeout=3)
            #ensure after the telnet, the network device display the (Username:), if display, give 0, if not give 1 
            result=session.expect(["Username: ",pexpect.TIMEOUT])
            
            #if network device dont display, give error messeage and break.
            if(result != 0):
                print(">   FAILED to connect to ",database_local['ipaddr'][a],"\n>   Reason : connection wrong\n")
                return False

            session.sendline(database_local['password'][a])
            result=session.expect(["Password: ",pexpect.TIMEOUT])

            if(result != 0):
                print(">   FAILED to connect to ",database_local['ipaddr'][a],"\n>   Reason : telnet username or password wrong\n")
                return False

            session.sendline(database_local['password'][a])
            result=session.expect([">",pexpect.TIMEOUT])

            if(result != 0):
                print(">   FAILED to connect to ",database_local['ipaddr'][a],"\n>   Reason : telnet username or password wrong\n")
                return False

            session.sendline("enable\n"+database_local['enapass'][a])
            result=session.expect(["#",pexpect.TIMEOUT])

            if(result != 0):
                print(">   FAILED to connect to ",database_local['ipaddr'][a],"\n>   Reason : enable password wrong\n")
                return False

            exec("%s(session)" % (command))
            print("------------------------------------------\n")
            session.close()
            a+=1
    else:
        print (" Belum ada data!")

def routecheck(session):
    session.sendline("show ip route | begin Gateway\n")
    result=session.expect(["#",pexpect.TIMEOUT])
    print(session.before.decode('UTF-8'),session.after.decode('UTF-8'))

def checkinterfaces(session):
    session.sendline("show ip int br | exclude down\n")
    result=session.expect(["#",pexpect.TIMEOUT])
    print(session.before.decode('UTF-8'))

def checkuptime(session):
    session.sendline("show version | i uptime\n")
    result=session.expect(["#",pexpect.TIMEOUT])
    print(session.before.decode('UTF-8'))


while True:
    os.system('clear')
    print(" Aplikasi EN-SDN 1")
    loop=int(input(" 1. Cek Device\n 2. Input Device\n 3. Configurasi Device\n 4. Exit (1/2/3/4) : "))
    if loop==1:
        os.system('clear')
        viewdev()
        input('\n Tekan sembarang untuk kembali ke menu')
    elif loop==2:
        os.system('clear')
        writedev()
        input('\n Tekan sembarang untuk kembali ke menu')
    elif loop==3:
        os.system('clear')
        menu()
        input('\n Tekan sembarang untuk kembali ke menu')
    elif loop==4:
        os.system('clear')
        break
    else:
        continue